This folder contains scripts

Clean_PyJupyter.bat
Cleans the PyJupyter folders
  Removes .pyc files
  Removes __pycache__
  Remove examples and Tests
  Remove notebook checkpoints
  Remove private folders
  Clears the SLab/PyJupyter/Files folder
