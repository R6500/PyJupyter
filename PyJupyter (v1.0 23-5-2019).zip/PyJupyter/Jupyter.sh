export PYTHONPATH=~/PyJupyter/Code
cd ~/PyJupyter/Jupyter
jupyter notebook

