---------------------------
 Example of Extra notebook
---------------------------

Uncompress this file inside the  PyJupyter/Jupyter/Extra folder

Then, use the Jupyter file explorer to navigate to the "Extra" folder, 
enter the "Extra Example" folder and open the "Extra Example.ipynb" notebook.


